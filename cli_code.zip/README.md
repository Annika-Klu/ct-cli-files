# BGH Churchtools-CLI

Command Line Interface to interact with BGH churchtools instance.
Based on churchtools REST API, authentication using personal API Token.